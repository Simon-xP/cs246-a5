#ifndef __GUI_H__
#define __GUI_H__

#include "window.h"

class gui {

};

#endif
